package com.example.test;

import com.example.test.API.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class AIRunner implements ApplicationRunner {

    @Autowired
    Test test;
    @Override
    public void run(ApplicationArguments args) throws Exception {
        test.send();

    }
}
