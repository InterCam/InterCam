package com.example.test.Entity;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Getter
@NoArgsConstructor
@Entity
@Setter
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class User { // 유저
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long user_id;

    @OneToOne
    private Major major_id;


    @OneToMany(mappedBy = "user_id", fetch = FetchType.LAZY,
            cascade = {CascadeType.DETACH, CascadeType.MERGE,
                    CascadeType.PERSIST, CascadeType.REFRESH}) // 동영상 리스트
    private List<VideoList> list_id;


    @NotNull @Column(unique = true)
    private String username; // 이메일(아이디)

    @NotNull
    private String name;

    @NotNull
    private String password; // 비밀번호

    @NotNull
    private String phone; // 전화번호

    private String birth; // 생일

    @Column(columnDefinition = "varchar(32) default 'User'")
    @Enumerated(EnumType.STRING) // 권한
    private Auth auth;


    @Builder
    public User(@NotNull String username, @NotNull String password,
                @NotNull String name,
                @NotNull String phone,
                String birth) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.birth = birth;
        this.auth = Auth.USER;
    }

    public void addVideoList(VideoList videoList){
        if(list_id == null){
            list_id = new ArrayList<>();
        }
        list_id.add(videoList);
        videoList.addUser(this);
    }

    //// User - Major
    public void addMajor(Major major){
        major_id = major;
        major.addUser(this);
    }

//    A --> B 1:N
//
//
//    1. B쪽에 A 데이터를 넣을 메서드(addUser)를 입력
//    2. A쪽에 B 데이터를 넣는데 --> A리스트.add(B) & B.1메서드(A) 동시에 이볅
}
