package com.example.test.Entity;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Getter
@NoArgsConstructor
@Entity
public class Notice extends BaseTimeEntity { // 공지사항
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long notice_id;

    @NotNull
    private String title; // 제목
    private int views; // 조회수

    @Builder
    public Notice(@NotNull String title, int views) {
        this.title = title;
        this.views = views;
    }
}
