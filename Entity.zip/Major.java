package com.example.test.Entity;

import lombok.*;

import javax.persistence.*;

@Entity @Getter @Setter
@AllArgsConstructor @NoArgsConstructor
public class Major {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long major_Id;

    private String name1;

    private String name2;

    private String name3;

    @OneToOne // 양방향
    private User user_id;

    @Builder // 최대로 받을 수 있는 관심항목 수를 정하기. (예 : 3개)
    public Major(String name1, String name2, String name3){
        this.name1 = name1;
        this.name2 = name2;
        this.name3 = name3;
    }

    public Major(String name1, String name2){
        this.name1 = name1;
        this.name2 = name2;
    }

    public Major(String name1){
        this.name1 = name1;
    }

    public void addUser(User user){ // User에서 addMajor로 할 것
        this.user_id = user;
    }

}
