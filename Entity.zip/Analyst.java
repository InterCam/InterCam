package com.example.test.Entity;

import lombok.*;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import java.util.List;

@DiscriminatorValue("ANALYST")
@Entity @Getter @Setter
@NoArgsConstructor
public class Analyst extends User{
    private String img; // 이미지 url

    @NotNull
    private String contents; // 이력 / 학력

    @OneToMany(mappedBy = "analyst_id")
    private List<Comment> comments;

    // 상속을 받아와야함으로 생성자 생성시 username .. 등등이 안 불려옴 service단에서 구현.
}
