package com.example.intercam.controller;

import com.example.intercam.Repository.AnalysisRepository;
import com.example.intercam.entity.Analyst;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AnalystController {

    @Autowired
    private AnalysisRepository analysisRepository;

    @GetMapping("/admin/analyst")
    public String addAnalyst(Model model){
        List<Analyst> analysts = analysisRepository.findAll();

        if(analysts == null){
            model.addAttribute("none");
        }
        model.addAttribute("analysts", analysts);
        return "admin/analyst";
    }

}
