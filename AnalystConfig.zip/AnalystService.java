package com.example.intercam.service;

import com.example.intercam.Repository.AnalysisRepository;
import com.example.intercam.entity.Analyst;
import com.example.intercam.entity.Comment;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AnalystService {
    @Autowired
    private AnalysisRepository analysisRepository;

    @PostConstruct
    public void addAna(){

        Analyst analyst = new Analyst();
        Analyst analyst2 = new Analyst();
        Analyst analyst3 = new Analyst();

        analyst.setName("피카츄");
        analyst.setPhone("010");
        analyst.setPassword("aa");
        analyst.setUsername("AA");
        analyst.setContents("a");
        analyst.setImg("./META-INF/cat.jpg");

        analyst2.setName("라이츄");
        analyst2.setPhone("010");
        analyst2.setPassword("aa");
        analyst2.setUsername("AA");
        analyst2.setContents("b");
        analyst2.setImg("./META-INF/cat.jpg");

        analyst3.setName("꼬북이");
        analyst3.setPhone("010");
        analyst3.setPassword("aa");
        analyst3.setUsername("AA");
        analyst3.setContents("c");
        analyst3.setImg("./META-INF/cat.jpg");

        analysisRepository.save(analyst);
        analysisRepository.save(analyst2);
        analysisRepository.save(analyst3);
    }

    // save
    @Transactional
    public void save(Analyst analyst){
        analysisRepository.save(analyst);
    }

    @Transactional
    public void save(String username, String name, String password, String phone, String img, String contents){
        Analyst analyst = new Analyst();

        analyst.setUsername(username);
        analyst.setPassword(password);
        analyst.setPhone(phone);
        analyst.setName(name);
        analyst.setImg(img);
        analyst.setContents(contents);

        analysisRepository.save(analyst);
    }

    @Transactional
    public List<Comment> getComment(Long ana_id){
        Optional <Analyst> ana = analysisRepository.findById(ana_id);
        List<Comment> anaComment = ana.get().getComments();
        return anaComment;
    }
}
