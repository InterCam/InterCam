package com.example.test.Entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.List;

@DiscriminatorValue("ANALYST")
@Entity @Getter @Setter
@NoArgsConstructor
public class Analyst extends User{
    private String img; // 이미지 url

    @NotNull
    private String contents; // 이력 / 학력

    @OneToMany(mappedBy = "analyst_id")
    private List<Comment> comments;

    @Column(columnDefinition = "varchar(32) default 'ANALYST'")
    @Enumerated(EnumType.STRING) // 권한
    private Auth완료 auth완료;

    // 상속을 받아와야함으로 생성자 생성시 username .. 등등이 안 불려옴 service단에서 구현.
}
