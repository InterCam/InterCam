package com.example.test.Entity;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Getter
@NoArgsConstructor
@Entity
public class Notice완료 extends BaseTimeEntity완료{ // 공지사항
    @Id @GeneratedValue
    private Long notice_id;

    @NotNull
    private String title; // 제목

    @Column(columnDefinition = "int(11) default 0")
    private int views; // 조회수

    private String contents; // 2021_02_20 : 없길래 추가함.

    @Builder
    public Notice완료(@NotNull String title, int views) {
        this.title = title;
        this.views = views;
    }
}
