package com.example.test.Entity;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Getter
@NoArgsConstructor
@Entity
public class FAQ완료 {
    @Id @GeneratedValue
    private Long faq_id;

    @NotNull // 제목
    @Column(columnDefinition = "VARCHAR(100)")
    private String title;

    @NotNull // 내용
    private String contents;

    @Builder
    public FAQ완료(@NotNull String title, @NotNull String contents) {
        this.title = title;
        this.contents = contents;
    }
}
