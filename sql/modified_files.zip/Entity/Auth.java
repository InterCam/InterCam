package com.example.test.Entity;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Auth완료 {
    ADMIN("ROLE_ADMIN","관리자"),
    ANALYST("ROLE_ANALYST","평가자"),
    USER("ROLE_USER","유저");

    private final String key;
    private final String title;
}
