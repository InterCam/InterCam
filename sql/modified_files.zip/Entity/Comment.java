package com.example.test.Entity;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Getter
@NoArgsConstructor
@Entity @Setter
public class Comment extends BaseTimeEntity완료 { // 댓글
    @Id  @GeneratedValue
    private Long comment_id;

    @ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.DETACH,
            CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
    @JoinColumn(name="list_id") // 유저 리스트
    private VideoList list_Id;


    @ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.DETACH,
            CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
    @JoinColumn(name="analyst_id") // 유저 리스트
    private Analyst analyst_id;


    @Lob @NotNull // 내용
    private String contents;

    @Column(columnDefinition = "int(11) default 0")
    private int score;

    @Builder
    public Comment(@NotNull String contents) {
        this.contents = contents;
    }

    //TODO 단방향 --> User를 추가하는 로직 생성
    public Comment(Analyst analyst){
        this.analyst_id = analyst;
    }

    public void addVideoList(VideoList videoList) {
        this.list_Id = videoList;
    }
}
