package com.example.test.Service;

import com.example.test.Entity.Major;
import com.example.test.Entity.User;
import com.example.test.Repository.MajorRepository;
import com.example.test.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@RequiredArgsConstructor
@Service
public class MajorService {
    private final MajorRepository majorRepository;
    private final UserRepository userRepository;

    @Transactional
    public void save(Major major){
        majorRepository.save(major);
    }


//    @Transactional
//    public void saveUser(Long userid, Major major){
//        majorRepository.save(major);
//
//        User user = userRepository.findById(userid).orElseThrow(()->new IllegalArgumentException("없는 회원"));
//        user.addMajor(major);
//    }

    @Transactional
    public Major findMajor(Long userid){
        User user = userRepository.findById(userid).orElseThrow(()->new IllegalArgumentException("없는 회원"));
        return user.getMajor_id();
    }

}
